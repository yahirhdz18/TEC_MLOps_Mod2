# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tec_mlops_mod2', 'tec_mlops_mod2.data', 'tec_mlops_mod2.todos']

package_data = \
{'': ['*']}

install_requires = \
['datetime>=4.7,<5.0',
 'pandas>=1.5.1,<2.0.0',
 'pathlib>=1.0.1,<2.0.0',
 'typer>=0.6.1,<0.7.0']

setup_kwargs = {
    'name': 'tec-mlops-mod2',
    'version': '0.1.0',
    'description': 'Project for Module 2 MLOps TEC',
    'long_description': '# TODOS\n',
    'author': 'Gabriel Yahir Hernandez Montes',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
