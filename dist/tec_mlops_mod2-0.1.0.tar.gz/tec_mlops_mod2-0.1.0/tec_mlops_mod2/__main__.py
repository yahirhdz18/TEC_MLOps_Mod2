from tec_mlops_mod2.main import app
app()